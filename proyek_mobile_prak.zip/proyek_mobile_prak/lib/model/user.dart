import 'package:hive/hive.dart';
part "user.g.dart";

//database model
@HiveType(typeId: 1)
class UserModel {
  UserModel({required this.username, required this.password});

  @HiveField(0)
  String username;

  @HiveField(1)
  String password;

  @override
  String toString() {
    return 'UserModel{username: $username, password: $password}';
  }
}
