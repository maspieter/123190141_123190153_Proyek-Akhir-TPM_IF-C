import 'package:flutter/material.dart';

class SubmitDaftar extends StatelessWidget {
  final String labelButton;
  final Function(String) submitCallback;

  const SubmitDaftar(
      {Key? key, required this.labelButton, required this.submitCallback}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            minimumSize: Size(100, 40),
            shape: StadiumBorder(),
            side: BorderSide(color: Colors.black26)),
        child: Text(
          labelButton,
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
        onPressed: () {
          submitCallback(labelButton);
        },
      ),
    );
  }
}
