class Weather {
  final String name;
  final String description;
  final String icon;
  final String country;
  final double temp;
  final double humidity;
  final double temp_min;
  final double temp_max;
  Weather({this.name = '', this.description = '', this.icon = '', this.country = '', this.temp = 0, this.humidity = 0, this.temp_min = 0, this.temp_max = 0 });


  factory Weather.fromJson(Map<String, dynamic> json) {
    return Weather(
      name: json['name'] ?? '',
      country: json['sys']['country'] ?? '',
      description: json['weather'][0]['description'] ?? '',
      icon: json['weather'][0]['icon'] ?? '',
      temp: json['main']['temp'] ?? 0,
      humidity: json['main']['humidity'] ?? 0,
      temp_min: json['main']['temp_min'] ?? 0,
      temp_max: json['main']['temp_max'] ?? 0,
    );
  }
}
