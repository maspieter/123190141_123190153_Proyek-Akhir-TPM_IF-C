import 'package:flutter/material.dart';
import 'package:proyek_mobile/model/user.dart';
import 'package:proyek_mobile/model/submit.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:proyek_mobile/view/login-page.dart';

class DaftarPage extends StatefulWidget {
  const DaftarPage({Key? key}) : super(key: key);

  @override
  State<DaftarPage> createState() => _DaftarPageState();
}

class _DaftarPageState extends State<DaftarPage> {
  Box<UserModel> database = Hive.box<UserModel>("user");
  final _formKey = GlobalKey<FormState>();
  final username_controller = TextEditingController();
  final password_controller = TextEditingController();
  String username = "";
  String password = "";

  void _submit(){
    if (_formKey.currentState!.validate()) {
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (context) => LoginPage(status: false,)),
              (_) => false,
      );
      database.add(UserModel(
          username: username_controller.text,
          password: password_controller.text));
      username_controller.clear();
      password_controller.clear();
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Berhasil mendaftar!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Form(
        key: _formKey,
        child: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/gambar/bg1.jpg'),
                  colorFilter: ColorFilter.mode(
                    Colors.black.withOpacity(0.4),
                    BlendMode.darken,
                  ),
                  fit: BoxFit.fill)),
          child: Column(
            children: <Widget>[
              Expanded(
                child: Container(
                  height: 400,
                ),
              ),
              Text(
                'DAFTAR',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 35,
                  color: Colors.white.withOpacity(0.9)
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Silahkan mendaftar terlebih dahulu',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white.withOpacity(0.9)
                ),
              ),
              Padding(
                padding: EdgeInsets.all(30.0),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          color: Colors.pinkAccent.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(100, 100, 100, 120),
                              blurRadius: 20.0,
                              offset: Offset(0, 10),
                            )
                          ]),
                      child: Column(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                                border: Border(
                                    bottom: BorderSide(color: Colors.black))),
                            child: TextFormField(
                              controller: username_controller,
                              decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: "Username",
                                  hintStyle:
                                  TextStyle(color: Colors.black)),
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Username tidak boleh kosong!!!';
                                } else {
                                  return null;
                                }
                              },
                              onChanged: (text) =>
                                  setState(() => username = text),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(8.0),
                            child: TextFormField(
                              obscureText: true,
                              controller: password_controller,
                              decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: "Password",
                                  hintStyle:
                                  TextStyle(color: Colors.black)),
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Password tidak boleh kosong!!!';
                                }
                                if (text.length < 8) {
                                  return 'Passwordmu lemah! Cepatan ganti!!';
                                } else {
                                  return null;
                                }
                              },
                              onChanged: (text) =>
                                  setState(() => password = text),
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 45,
                    ),
                    Container(
                      child: Column(
                        children: [
                          _daftarButton(),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 180,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
  Widget _daftarButton() {
    return Submit(
        labelButton: "Daftar",
        submitCallback: (value) {
          _submit();
        });
  }
}
