import 'package:flutter/material.dart';
import 'package:proyek_mobile/service/data_service.dart';
import 'package:proyek_mobile/service/weather.dart';
import 'package:proyek_mobile/view/login-page.dart';
import 'dart:async';
import 'dart:ui';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  final String username;
  final bool statusLogin;

  HomePage({Key? key, required this.username, required this.statusLogin}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Future<SharedPreferences> _myPref = SharedPreferences.getInstance();
  TextEditingController controller = TextEditingController();
  DataService dataService = DataService();
  Weather weather = Weather();
  bool isFetch = false;

  void initial() async{
    logindata = await SharedPreferences.getInstance();
    setState(() {
      username = "${widget.username}";
    });
  }

  void _prosesLogout(bool status, String username) async {
    SharedPreferences getPref = await _myPref;
    await getPref.setBool("LoginStatus", status);
    await getPref.setString("Username", username);
  }

  late SharedPreferences logindata;
  String? username;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Informasi Cuaca',
          style: TextStyle(
          color: Colors.white,
        ),),
        backgroundColor: Colors.indigo,

        actions: [IconButton(
          icon: Icon(Icons.logout),
          onPressed: () {
            bool status = false;
            _prosesLogout(status, widget.username);
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) {
                  return LoginPage(status: status);
                }));
          },
        ),],
      ),
      body:
      Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/gambar/bg5.png'),
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.1),
                  BlendMode.darken,
                ),
                fit: BoxFit.fill)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            isFetch ?
            Column(
              children: [
                Image.network('http://openweathermap.org/img/wn/${weather.icon}@2x.png'),
                Text('${weather.description}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),),
                Text('Location: ${weather.name}, ${weather.country}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),),
                Text('Temperature : ${weather.temp}°C',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),),
                Text('Temperature Min : ${weather.temp_min}°C',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),),
                Text('Temperature Max :${weather.temp_max}°C',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),),
                Text('Humidity : ${weather.humidity}%',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),)
              ],
            ) : SizedBox( height: 25,),
            Container(
              width: 150,
              padding: EdgeInsets.symmetric(vertical: 50),
              child: TextField(
                controller: controller,
                textAlign: TextAlign.center,
                decoration: InputDecoration(labelText: 'Input wilayah :'),
              ),
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 8),
                    minimumSize: Size(100, 40),
                    shape: StadiumBorder(),
                    side: BorderSide(color: Colors.black26)),
                onPressed: () async {
                    isFetch = true;
                    weather = await dataService.fetchData(controller.text);
                    setState(() {});
            }, child: Text('Cari')),
          ],
        ),
      ),
    );
  }
}


