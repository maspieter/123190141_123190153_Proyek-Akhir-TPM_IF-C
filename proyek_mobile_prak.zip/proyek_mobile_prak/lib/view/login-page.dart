import 'package:flutter/material.dart';
import 'package:proyek_mobile/model/submit_daftar.dart';
import 'package:proyek_mobile/view/daftar_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:proyek_mobile/view/home_page.dart';
import 'package:proyek_mobile/model/user.dart';
import 'package:proyek_mobile/model/submit.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

class LoginPage extends StatefulWidget {
  final bool status;

  const LoginPage({Key? key, required this.status}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late Box<UserModel> database = Hive.box<UserModel>("user");
  final Future<SharedPreferences> logindata = SharedPreferences.getInstance();
  final _formKey = GlobalKey<FormState>();
  final username_controller = TextEditingController();
  final password_controller = TextEditingController();
  String username = "";
  String password = "";
  late bool statusLogin = widget.status;

  void _submit() {
    if (_formKey.currentState!.validate()) {
      String currentUsername = username_controller.value.text;
      String currentPassword = password_controller.value.text;
      _cekLogin(currentUsername, currentPassword);
    }
  }

  void _cekLogin(String username, String password) async {
    for (int index = 0; index < database.length; index++) {
      if (username == database.getAt(index)!.username && password == database.getAt(index)!.password) {
        statusLogin = true;
        SharedPreferences getPref = await logindata;
        await getPref.setBool("StatusLogin", statusLogin);
        await getPref.setString("Username", username);
        Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (context) {
          return HomePage(username: username,
            statusLogin: statusLogin,
          );
        }), (_) => false);
      }
    }
  }

  void dispose(){
    username_controller.dispose();
    password_controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Form(
        key: _formKey,
        child: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/gambar/bg1.jpg'),
                  colorFilter: ColorFilter.mode(
                      Colors.black.withOpacity(0.4),
                      BlendMode.darken,
                  ),
                  fit: BoxFit.fill)),
          child: Column(
            children: <Widget>[
              Expanded(
                child: Container(
                  height: 400,
                ),
              ),
              Text(
                'LOGIN',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 35,
                  color: Colors.white.withOpacity(0.9),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Selamat datang, silahkan login!',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white.withOpacity(0.9)
                ),
              ),
              Padding(
                padding: EdgeInsets.all(30.0),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          color: Colors.pinkAccent.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(100, 100, 100, 120),
                              blurRadius: 20.0,
                              offset: Offset(0, 10),
                            )
                          ]),
                      child: Column(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                                border: Border(
                                    bottom: BorderSide(color: Colors.black))),
                            child: TextFormField(
                              controller: username_controller,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: "Username",
                                hintStyle:
                                TextStyle(color: Colors.black)),
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Username tidak boleh kosong!!!';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(8.0),
                            child: TextFormField(
                              obscureText: true,
                              controller: password_controller,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: "Password",
                                hintStyle:
                                TextStyle(color: Colors.black)
                              ),
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Password tidak boleh kosong!!!';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Container(
                      child: Column(
                        children: [
                          _loginButton(),
                          _daftarButton(),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 150,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _loginButton() {
    return Submit(
      labelButton: "Login",
      submitCallback: (value) {
        _submit();
      });
  }

  Widget _daftarButton() {
    return SubmitDaftar(
        labelButton: "Daftar",
        submitCallback: (value) {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => DaftarPage()),
          );
        });
  }
}
