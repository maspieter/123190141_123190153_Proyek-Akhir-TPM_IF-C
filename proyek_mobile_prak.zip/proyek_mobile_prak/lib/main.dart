import 'package:flutter/material.dart';
import 'package:proyek_mobile/view/login-page.dart';
import 'package:proyek_mobile/view/home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'model/user.dart';

Future<void> main() async {
  database();
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences pref = await SharedPreferences.getInstance();
  bool status = pref.getBool("LoginStatus") ?? false;
  String username = pref.getString("Username") ?? "";
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      primarySwatch: Colors.cyan,
    ),
    home: status == true
        ? HomePage(username: username, statusLogin: status)
        : LoginPage(status: false),
  ));
}

void database() async {
  await Hive.initFlutter();
  Hive.registerAdapter(UserModelAdapter());
  await Hive.openBox<UserModel>("user");
}
